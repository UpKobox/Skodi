xbmc.executebuiltin('Addon.OpenSettings(script.xbmcbackup)') 
