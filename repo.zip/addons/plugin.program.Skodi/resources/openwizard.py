xbmc.executebuiltin('Dialog.Close(busydialog)')
xbmc.executebuiltin('RunAddon(plugin.program.openwizard)')