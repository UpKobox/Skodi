xbmc.executebuiltin('Dialog.Close(busydialog)')
xbmc.executebuiltin('RunAddon(plugin.video.sendtokodiU2P)')