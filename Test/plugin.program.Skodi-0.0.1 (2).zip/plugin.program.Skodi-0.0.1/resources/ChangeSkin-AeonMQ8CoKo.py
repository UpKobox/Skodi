xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin" ,"value":"skin.aeonmq8.matrix.mod"}}')
xbmc.executebuiltin('SendClick(11)')
